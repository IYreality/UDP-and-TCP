#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <iostream>
#include <memory.h>
#include <string>
#include <string.h>
#include <ctime>
#define BUFFER_SIZE 1024
#define MAX_FILE_NAME 1024
#include <cstdlib>
#include <pthread.h>
using namespace std;

const int num_threads = 9;
char *file_buffer;
int p_port = 10000;

/*The arg passed to fun in thread
	1- name of file to write (has '_' before name of file received)
	2- sock in this thread (num_threads socks counted)
	3- seperated file to buffer
	4- size of buffer in 3*/
struct port_file
{
	const char *file_name;
	int sock;
	char* file_buffer_son;
	long buffer_son_len;
};

void* recv_write(void *_p);
int startup(int _port, const char *_ip);

int main(int argc,const char* argv[])
{
    int p_num = num_threads;
    if(argc != 3)
    {
        cerr << "Usage: " << argv[0] << " [local_ip] [local_port]" << endl;
        return 1;
    }

    /*tcp to send file_name required*/
    int sock;
	int _port = atoi(argv[2]);
	string _addr = argv[1];
	while ((sock = startup(_port, _addr.c_str())) == -1)
	{
		cout << "Please input available address and port - [address] [port]: ";
		cin >> _addr >> _port;
	}

	/*input file_name required*/
	char file_name[MAX_FILE_NAME];
    memset(file_name, '\0', sizeof(file_name));
    char buffer[BUFFER_SIZE];
    memset(buffer, '\0', sizeof(buffer));
    cout << "Send Request -- File name required: ";
    scanf("%s", file_name);
    strncpy(buffer, file_name, strlen(file_name) > BUFFER_SIZE ? BUFFER_SIZE : strlen(file_name));
    /*_file_name add '_' before file_name*/
    char _file_name[MAX_FILE_NAME + 1] = {"_"};
    strcat(_file_name, file_name);

    /*send file name required*/
    if (send(sock, buffer, BUFFER_SIZE, 0) < 0)
    {
        cerr << "Fail to Request!" << endl;
        exit(1);
    }

    /*get file information add print*/
    cout << "\n" << file_name << "\n -- File Name --" << endl;
    recv(sock, buffer, BUFFER_SIZE, 0);
    cout << buffer << endl;
    
    /*get file length*/
    string temp_s = buffer;
    temp_s = temp_s.substr(0, temp_s.find(" "));
    long file_len_p = atoi(temp_s.c_str());

    /*create array of arg to thread func and add in arg*/
    struct port_file pf[num_threads];
    long buffer_son_seg = file_len_p;
    char ** file_buffer_son = NULL;
    file_buffer_son = new char *[num_threads];
    /*the last piece/thread contains not exactly per_seg, thus do specialy*/
    long per_seg = file_len_p / num_threads;
    for (int i = 0; i < num_threads - 1; i ++)
    {
    	file_buffer_son[i] = new char[per_seg];
    	for (int j = 0; j < per_seg; j ++)
    		file_buffer_son[i][j] = 0;
    	file_buffer_son[i][per_seg - 1] = '\0';

    	pf[i].file_buffer_son = file_buffer_son[i];
    	buffer_son_seg -= per_seg;
    	(pf[i]).buffer_son_len = per_seg;
    }
    file_buffer_son[num_threads - 1] = new char[buffer_son_seg];
    (pf[num_threads - 1]).buffer_son_len = buffer_son_seg;
    pf[num_threads - 1].file_buffer_son = file_buffer_son[num_threads - 1];
    for (int j = 0; j < buffer_son_seg; j ++)
    		file_buffer_son[num_threads - 1][j] = 0;
    	file_buffer_son[num_threads - 1][per_seg - 1] = '\0';

    close(sock);

    int listen_port_pthreads[num_threads];

	for (int i = 0; i < num_threads; i ++)
	{
		(pf[i]).file_name = _file_name;
		(pf[i]).file_buffer_son = file_buffer_son[i];
	}

	for (int i = 0; i < num_threads; i ++)
	{
		listen_port_pthreads[i] = p_port;
		p_port ++;
		while (((pf[i]).sock = startup(listen_port_pthreads[i], _addr.c_str())) == -1)
		{
			listen_port_pthreads[i] = p_port;
			p_port ++;
		}
	}

	pthread_t threads[num_threads];
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
	int rc;
	void *status;

	for (int i = 0; i < num_threads; i ++)
	{
		cout << "Tread " << i << " : Start transfering." << endl;
		if ((rc = pthread_create(&threads[i], NULL, recv_write, (void *)&(pf[i]))))
		{
			cout << "Unable to  create thread, " << rc << endl;
			exit(-1);
		}
	}

	pthread_attr_destroy(&attr);
	for (int i = 0; i < num_threads; i ++)
	{
		if ((rc = pthread_join(threads[i], &status)))
		{
			cout << "Unable to  join thread, " << rc << endl;
			exit(-1);
		}
			cout << "Thread " << i << " : Complete transfering." << endl;
	}

	for (int i = 0; i < num_threads; i ++)
	{
		close(pf[i].sock);
	}

	FILE* f_merge = fopen(_file_name, "w");
	for (int i = 0; i < num_threads; i ++)
	{
		fwrite(file_buffer_son[i], sizeof(char), pf[i].buffer_son_len, f_merge);
	}
	fclose(f_merge);
    for (int i = 0; i < num_threads; i ++)
    {
    	delete[] file_buffer_son[i];
    	file_buffer_son[i] = NULL;
    }
    delete[] file_buffer_son;
    return 0;
}

void* recv_write(void* _p)
{
	struct port_file* p = (struct port_file*)_p;
	char buffer[1024];
	memset(buffer, '\0', BUFFER_SIZE);
	long f_seg = p -> buffer_son_len;

	int seek_s = 0;
    while (1)
    {
    	long seg_size = f_seg > BUFFER_SIZE ? BUFFER_SIZE : f_seg;
    	bool flag = f_seg > BUFFER_SIZE ? false : true;
    	f_seg -= BUFFER_SIZE;
    	recv(p -> sock, buffer, seg_size, 0);
    	for (int i = 0; i < seg_size; i ++, seek_s ++)
    	{
    		p -> file_buffer_son[seek_s] = buffer[i];
    	}

        memset(buffer, '\0', BUFFER_SIZE);
        if (flag)
        	break;
    }
}

int startup(int _port, const char *_ip)
{
	int sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0)
	{
		cerr << "Error: Server builds socket unsuccessfully!" << endl;
		return -1;
	}

	struct sockaddr_in server;
	server.sin_family = AF_INET;
	server.sin_port = htons(_port);
	server.sin_addr.s_addr = inet_addr(_ip);
	socklen_t len = sizeof(server);

	if (connect(sock, (struct sockaddr*)&server, len) < 0)
    {
        cerr << "Error: Cilent fails to connect!" << endl;
        return -1;
    }
	return sock;
}