#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <memory.h>
#include <string.h>
#include <fcntl.h>
#include <time.h>
#include <sys/stat.h>
#include <cstdlib>
#include <pthread.h>
#define BUFFER_SIZE 1024
#define MAX_FILE_NAME 1024
using namespace std;

const int num_threads = 9;
int p_port = 10000;

struct port_file
{
	const char *file_name;
	int listen_sock;
	char* file_buffer_son;
	long buffer_son_len;
	long f_start;
};

void* read_send(void *_p);
int startup(int _port, const char *_ip);

int main(int argc, char const *argv[])
{
	int p_num = num_threads;
	FILE *fp;
	if (argc != 3)
	{
		cerr << "Usage: " << argv[0] << " [local_ip] [local_port]" << endl;
		return 1;
	}

	int listen_sock;
	int _port = atoi(argv[2]);
	string _addr = argv[1];
	while ((listen_sock = startup(_port, _addr.c_str())) == -1)
	{
		cout << "Please input available address and port - [address] [port]: ";
		cin >> _addr >> _port;
	}

	struct sockaddr_in remote;
	socklen_t len = sizeof(struct sockaddr_in);

	int resp_sock;
	resp_sock = accept(listen_sock, (struct sockaddr*)&remote, &len);
	//while (1)
	{
		if (resp_sock < 0)
		{
			cerr << "Server Fail to accept!" << endl;
			exit(1);
		}
		cout << "Get a cilent, ip: " << inet_ntoa(remote.sin_addr) << ", port: " << ntohs(remote.sin_port) << endl;
		char buffer[1024];
		memset(buffer, '\0', sizeof(buffer));
		if (recv(resp_sock, buffer, BUFFER_SIZE, 0) < 0)
		{
			cerr << "Fail to receive!" << endl;
			exit(1);
		}
		char file_name[MAX_FILE_NAME];
		memset(file_name, 0, sizeof(file_name));
		strncpy(file_name, buffer, strlen(buffer) > MAX_FILE_NAME ? MAX_FILE_NAME : strlen(buffer));
		cout << "Receive Request -- File name required: " << file_name << endl;
		
		memset(buffer, '\0', BUFFER_SIZE);
		struct stat buf;
		int result = stat(file_name, &buf);
		if (result != 0)
		{
			cerr << "Fail to show file information!" << endl;
			exit(1);
		}

		FILE *fp = fopen(file_name, "r");
		if (NULL == fp)
		{
			cerr << "File: " << file_name << " not found!" << endl;
		}
		else
		{
			char filesize[100] = {};
			sprintf(filesize, "%ld", buf.st_size);
			strcat(buffer, filesize);
			strcat(buffer, " bytes\n");
			strcat(buffer, " -- File Size --\n");
			strcat(buffer, ctime(&buf.st_ctime));
			strcat(buffer, " -- Create Time --\n");
			strcat(buffer, ctime(&buf.st_mtime));
			strcat(buffer, " -- Modified Time --\n");
			send(resp_sock, buffer, BUFFER_SIZE, 0);
		}
		
		struct port_file pf[num_threads];
    	long buffer_son_seg = buf.st_size;
    	long f_start[num_threads];
    	long per_seg = buf.st_size / num_threads;
    	for (int i = 0; i < num_threads - 1; i ++)
    	{
    		buffer_son_seg -= per_seg;
    		(pf[i]).buffer_son_len = per_seg;
    	}
    	(pf[num_threads - 1]).buffer_son_len = buffer_son_seg;
    	
		fclose(fp);
		close(resp_sock);
		close(listen_sock);

		int listen_port_pthreads[num_threads];

		for (int i = 0; i < num_threads; i ++)
		{
			(pf[i]).file_name = file_name;
			f_start[i] = i == 0 ? 0 : f_start[i - 1] + per_seg;
			pf[i].f_start = f_start[i];

			listen_port_pthreads[i] = p_port;
			p_port ++;
			while (((pf[i]).listen_sock = startup(listen_port_pthreads[i], _addr.c_str())) == -1)
			{

				listen_port_pthreads[i] = p_port;
				p_port ++;
			}
		}

		pthread_t threads[num_threads];
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
		int rc;
		void *status;

		clock_t begin = clock();
		for (int i = 0; i < num_threads; i ++)
		{
			cout << "Tread " << i << " : Start transfering." << endl;
			if ((rc = pthread_create(&threads[i], NULL, read_send, (void *)&(pf[i]))))
			{
				cout << "Unable to  create thread, " << rc << endl;
				exit(-1);
			}
		}

		pthread_attr_destroy(&attr);
		for (int i = 0; i < num_threads; i ++)
		{
			if ((rc = pthread_join(threads[i], &status)))
			{
				cout << "Unable to  join thread, " << rc << endl;
				exit(-1);
			}
			cout << "Thread " << i << " : Complete transfering." << endl;
		}
		clock_t end = clock();
        double secs = static_cast<double>(end - begin) / CLOCKS_PER_SEC;
        cout << "\nTime cost to send file: " << secs << "s" << endl;

		for (int i = 0; i < num_threads; i ++)
		{
			close(pf[i].listen_sock);
		}
	}
	return 0;
}

void* read_send(void * _p)
{

	struct port_file* p = (struct port_file*)_p;

	struct sockaddr_in remote;
	socklen_t len = sizeof(struct sockaddr_in);

	int resp_sock;
	resp_sock = accept(p -> listen_sock, (struct sockaddr*)&remote, &len);

	char buffer[1024];
	memset(buffer, '\0', BUFFER_SIZE);

	FILE *fp = fopen(p -> file_name, "r");
	if (NULL == fp)
	{
		cerr << "File: " << p -> file_name << " not found!" << endl;
	}
	long f_seg = p -> buffer_son_len;

	fseek(fp, p -> f_start, SEEK_SET);

    while (1)
    {
    	long seg_size = f_seg > BUFFER_SIZE ? BUFFER_SIZE : f_seg;
    	bool flag = f_seg > BUFFER_SIZE ? false : true;
    	f_seg -= BUFFER_SIZE;

    	fread(buffer, sizeof(char), seg_size, fp);
    	send(resp_sock, buffer, seg_size, 0);

        memset(buffer, '\0', BUFFER_SIZE);
        if (flag)
        	break;
    }


	fclose(fp);
	close(resp_sock);
}

int startup(int _port, const char *_ip)
{
	int sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0)
	{
		cerr << "Error: Server builds socket unsuccessfully!" << endl;
		return -1;
	}

	struct sockaddr_in local;
	local.sin_family = AF_INET;
	local.sin_port = htons(_port);
	local.sin_addr.s_addr = inet_addr(_ip);
	socklen_t len = sizeof(local);

	if (bind(sock, (struct sockaddr*)&local, len) < 0)
	{
		cerr << "Error: Server binds socket unsuccessfully!" << endl;
		return -1;
	}

	if (listen(sock, 8) < 0)
	{
		cerr << "Error: Server fail to listen!" << endl;
		return -1;
	}

	return sock;
}