#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <memory.h>
#include <string.h>
#include <fcntl.h>
#include <time.h>
#include <sys/stat.h>
#define BUFFER_SIZE 1024
#define MAX_FILE_NAME 1024
using namespace std;

int startup(int _port, const char* _ip)
{
	int sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0)
	{
		cerr << "Error: Server builds socket unsuccessfully!" << endl;
		exit(1);
	}

	struct sockaddr_in local;
	local.sin_family = AF_INET;
	local.sin_port = htons(_port);
	local.sin_addr.s_addr = inet_addr(_ip);
	socklen_t len = sizeof(local);

	if (bind(sock, (struct sockaddr*)&local, len) < 0)
	{
		cerr << "Error: Server binds socket unsuccessfully!" << endl;
		exit(2);
	}

	if (listen(sock, 8) < 0)
	{
		cerr << "Error: Server fail to listen!" << endl;
		exit(3);
	}

	return sock;
}

int main(int argc, char const *argv[])
{
	clock_t startTime,endTime;
	FILE *fp;
	if (argc != 3)
	{
		cerr << "Usage: " << argv[0] << " [local_ip] [local_port]" << endl;
		return 1;
	}

	int listen_sock = startup(atoi(argv[2]), argv[1]);

	struct sockaddr_in remote;
	socklen_t len = sizeof(struct sockaddr_in);

	int resp_sock;
	resp_sock = accept(listen_sock, (struct sockaddr*)&remote, &len);
	//while (1)
	{
		if (resp_sock < 0)
		{
			cerr << "Server Fail to accept!" << endl;
			exit(1);
		}
		cout << "Get a cilent, ip: " << inet_ntoa(remote.sin_addr) << ", port: " << ntohs(remote.sin_port) << endl;
		char buffer[1024];
		memset(buffer, 0, sizeof(buffer));
		if (recv(resp_sock, buffer, BUFFER_SIZE, 0) < 0)
		{
			cerr << "Fail to receive!" << endl;
			exit(1);
		}
		char file_name[MAX_FILE_NAME];
		memset(file_name, 0, sizeof(file_name));
		strncpy(file_name, buffer, strlen(buffer) > MAX_FILE_NAME ? MAX_FILE_NAME : strlen(buffer));
		startTime = clock();
		cout << "Receive Request -- File name required: " << file_name << endl;
		
		memset(buffer, 0, BUFFER_SIZE);
		struct stat buf;
		int result = stat(file_name, &buf);
		if (result != 0)
		{
			cerr << "Fail to show file information!" << endl;
			exit(1);
		}

		clock_t begin;
		FILE *fp = fopen(file_name, "r");
		if (NULL == fp)
		{
			cerr << "File: " << file_name << " not found!" << endl;
		}
		else
		{
			strcat(buffer, "File Size: ");
			char filesize[100] = {};
			sprintf(filesize, "%ld", buf.st_size);
			strcat(buffer, filesize);
			strcat(buffer, " bytes");
			strcat(buffer, "\n");
			strcat(buffer, "Create Time: ");
			strcat(buffer, ctime(&buf.st_ctime));
			strcat(buffer, "Modified Time: ");
			strcat(buffer, ctime(&buf.st_mtime));
			send(resp_sock, buffer, BUFFER_SIZE, 0);

			memset(buffer, 0, BUFFER_SIZE);
			int length = 0;
			begin = clock();

			while ((length = fread(buffer, sizeof(char), BUFFER_SIZE, fp)) > 0)
			{
				if (send(resp_sock, buffer, length, 0) < 0)
				{
					cerr << "Fail to send file: " << file_name << "!" << endl;
					exit(1);
				}
				memset(buffer, 0, BUFFER_SIZE);
			}

			cout << "Succeed to transfer file: " << file_name << "!" << endl;
		}
		fclose(fp);
		close(resp_sock);

		clock_t end = clock();
        double secs = static_cast<double>(end - begin) / CLOCKS_PER_SEC;
        cout << "Time cost to send file: " << secs << "s" << endl;
		endTime = clock();
		cout << "Total Time : " << (double)(endTime - startTime)/CLOCKS_PER_SEC << "s" << endl;

	}
	close(listen_sock);

	return 0;
}