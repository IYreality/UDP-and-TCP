#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <iostream>
#include <memory.h>
#include <string>
#include <ctime>
#define BUFFER_SIZE 1024
#define MAX_FILE_NAME 1024
using namespace std;

int startup(int _port, const char* _ip)
{
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0)
    {
        cerr << "Error: Server builds socket unsuccessfully!" << endl;
        exit(1);
    }

    struct sockaddr_in server;
    server.sin_family = AF_INET;
    server.sin_port = htons(_port);
    server.sin_addr.s_addr = inet_addr(_ip);
    socklen_t len = sizeof(server);

    if (connect(sock, (struct sockaddr*)&server, len) < 0)
    {
        cerr << "Error: Cilent fails to connect!" << endl;
        exit(1);
    }

    return sock;
}

int main(int argc,const char* argv[])
{
	clock_t startTime,endTime;
    FILE *fp;
    if(argc != 3)
    {
        cerr << "Usage: " << argv[0] << " [local_ip] [local_port]" << endl;
        return 1;
    }

    int sock = startup(atoi(argv[2]), argv[1]);

    char buffer[BUFFER_SIZE];
    char file_name[MAX_FILE_NAME];
    memset(file_name, 0, sizeof(file_name));
    memset(buffer, 0, sizeof(buffer));
    //while(1)
    {
        cout << "Send Request -- File name required: ";
        scanf("%s", file_name);
        strncpy(buffer, file_name, strlen(file_name) > BUFFER_SIZE ? BUFFER_SIZE : strlen(file_name));
        char temp[MAX_FILE_NAME + 1] = {"_"};
        strcat(temp, file_name);

        if (send(sock, buffer, BUFFER_SIZE, 0) < 0)
        {
            cerr << "Fail to Request!" << endl;
            exit(1);
        }
		startTime = clock();
        FILE *fp = fopen(temp, "w");
        if (fp == NULL)
        {
            cerr << "Fail to open file!" << endl;
            exit(1);
        }

        cout << "\nFile Name: " << file_name << endl;
        recv(sock, buffer, BUFFER_SIZE, 0);
        cout << buffer << endl;

        memset(buffer, 0, sizeof(buffer));
        int length = 0;

        while ((length = recv(sock, buffer, BUFFER_SIZE, 0)) > 0)
        {
            if (fwrite(buffer, sizeof(char), length, fp) < length)
            {
                cerr << "Fail to write to file!" << endl;
                break;
            }
            memset(buffer, 0, BUFFER_SIZE);
        }
		endTime = clock();
		cout << "Total Time : " << (double)(endTime - startTime)/CLOCKS_PER_SEC << "s" << endl;
        fclose(fp);
        memset(file_name, 0, sizeof(file_name));
        memset(buffer, 0, sizeof(buffer));
    }
    close(sock);
    return 0;
}